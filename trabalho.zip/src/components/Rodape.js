import { Col } from 'reactstrap';

function Rodape() {
    return (
        <div>
            <Col className='bg-dark text-light text-center py-5'>
                <spam>&copy; Filhas da Luta - Todos os direitos reservados </spam>
            </Col>
        </div>
    )
}
export default Rodape;